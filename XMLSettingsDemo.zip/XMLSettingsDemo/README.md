# XMLSettingsDemo
The accompanying demo application to the CodeProject article
